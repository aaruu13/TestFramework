package StepDefinations;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Features",glue= {"StepDefinations"},
monochrome = true,
tags="@Test"
		)

public class TestRunner {

}
