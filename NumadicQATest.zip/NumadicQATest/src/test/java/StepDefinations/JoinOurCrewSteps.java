package StepDefinations;

import static org.junit.Assert.assertThat;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class JoinOurCrewSteps {

	private By firstname=By.id("firstName");
	WebDriver driver = null;

	@Given("^User is on Home Page of Join Our Crew$")
	public void user_is_on_home_page_of_join_our_crew() {
		
		String path1 = System.getProperty("user.dir");
    
		System.setProperty("webdriver.chrome.driver", path1+"/src/test/resources/drivers/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    //navigate to join and crew website
	    driver.navigate().to("https://numadic.com/careers/");
	    String ActualHeading = driver.findElement(By.xpath("/html/body/header/div/div/div/div/h1")).getText();
	    String ExpectedHeading = "JOIN OUR CREW";
	    Assert.assertEquals(ExpectedHeading, ActualHeading);
	    System.out.println("Heading verified : Join Our Crew");
	    
	}

	@And("^verify internship job type validation$")
	public void verify_internship_job_type_validation() {
	   Select jobtype = new Select(driver.findElement(By.id("job_type")));
	   jobtype.selectByVisibleText("Internship");
	   String Actual1 = driver.findElement(By.xpath("//*[@id=\"job-posts-table\"]/tbody/tr/td")).getText();
	   String Expected1 = "There are no available job positions that match your filters.";
	   Assert.assertEquals(Expected1, Actual1);
	   System.out.println("Message is verified - There are no available job positions that match your filters.");
	}

	@When("^user selects job type as full time -> QA engineer -> verify url$")
	public void user_selects_job_type_as_full_time() {
	  Select jobtype = new Select(driver.findElement(By.id("job_type")));
	  jobtype.selectByVisibleText("Full time");
	  driver.findElement(By.xpath("//*[@id=\"job-posts-table\"]/tbody/tr[13]/td[2]/a")).click();
	  String Actualurl = driver.getCurrentUrl();
	  String Expectedurl = "https://numadic.com/careers/qa-engineer.php";
	  Assert.assertEquals(Expectedurl, Actualurl);
	  System.out.println("URL verified - https://numadic.com/careers/qa-engineer.php.");
	  
	}

	@Then("^verify apply here now button and click action$")
	public void verify_apply_here_now_button_and_click_action() {
	driver.findElement(By.xpath("/html/body/section/div/div[2]/div/a")).click();
	System.out.println("Verified Apply now button working fine");
	}

	@Then("^user will be redirected to career page$")
	public void user_will_be_redirected_to_career_page() {
	  String Actualurl = driver.getCurrentUrl();
	  String Expectedurl = "https://numadic.com/careers/#careersFormContainer";
	  Assert.assertEquals(Expectedurl, Actualurl);
	  System.out.println("Verified User is redirected to career page");
	
	}

	@Then("^user will hover on QA engineer select apply and validate personal details$")
	public void user_will_hover_on_QA_engineer_select_apply_and_validate_personal_details() {
		WebElement button1 = driver.findElement(By.xpath("/html/body/section[1]/div/div[3]/div/div/div/table/tbody/tr[13]/td[5]/button"));
		button1.click();
		//Check first name is enabled and displayed
				boolean isEnabled1 = driver.findElement(By.xpath("//*[@id=\"firstName\"]")).isDisplayed();
				boolean isDisplayed1 = driver.findElement(By.xpath("//*[@id=\"firstName\"]")).isEnabled();
				//Check last name is enabled and displayed
				boolean isEnabled2 = driver.findElement(By.xpath("//*[@id=\"lastName\"]")).isDisplayed();
				boolean isDisplayed2 = driver.findElement(By.xpath("//*[@id=\"lastName\"]")).isEnabled();

				//Check email is enabled and displayed
				boolean isEnabled3 = driver.findElement(By.xpath("//*[@id=\"email\"]")).isDisplayed();
				boolean isDisplayed3 = driver.findElement(By.xpath("//*[@id=\"email\"]")).isEnabled();

				//Check mobile number is enabled and displayed
				boolean isEnabled4 = driver.findElement(By.xpath("//*[@id=\"phone\"]")).isDisplayed();
				boolean isDisplayed4 = driver.findElement(By.xpath("//*[@id=\"phone\"]")).isEnabled();

				//Check current city is enabled and displayed
				boolean isEnabled5 = driver.findElement(By.xpath("//*[@id=\"current_city\"]")).isDisplayed();
				boolean isDisplayed5 = driver.findElement(By.xpath("//*[@id=\"current_city\"]")).isEnabled();

				//Check hometown is enabled and displayed
				boolean isEnabled6 = driver.findElement(By.xpath("//*[@id=\"hometown\"]")).isDisplayed();
				boolean isDisplayed6 = driver.findElement(By.xpath("//*[@id=\"hometown\"]")).isEnabled();

				//Check date of birth is enabled and displayed
				boolean isEnabled7 = driver.findElement(By.xpath("//*[@id=\"dob\"]")).isDisplayed();
				boolean isDisplayed7 = driver.findElement(By.xpath("//*[@id=\"dob\"]")).isEnabled();

				//Check specialization is enabled and displayed
				boolean isEnabled8 = driver.findElement(By.xpath("//*[@id=\"graduation_course\"]")).isDisplayed();
				boolean isDisplayed8 = driver.findElement(By.xpath("//*[@id=\"graduation_course\"]")).isEnabled();

				//Check college is enabled and displayed
				boolean isEnabled9 = driver.findElement(By.xpath("//*[@id=\"graduation_college\"]")).isDisplayed();
				boolean isDisplayed9 = driver.findElement(By.xpath("//*[@id=\"graduation_college\"]")).isEnabled();

				//Check percentage is enabled and displayed
				boolean isEnabled10 = driver.findElement(By.xpath("//*[@id=\"graduation_percentage\"]")).isDisplayed();
				boolean isDisplayed10 = driver.findElement(By.xpath("//*[@id=\"graduation_percentage\"]")).isEnabled();

				//verify sports dropdown
				WebElement sport= driver.findElement(By.id("sports"));
				Select select = new Select(sport);
				List<WebElement> options = select.getOptions();
				for(WebElement we:options)
				{
					System.out.println("verified sports dropdown");
					System.out.println(we.getText());
				}

				//verify dogs or cats dropdown
				WebElement pets= driver.findElement(By.id("pets"));
				Select select2 = new Select(pets);
				List<WebElement> options2 = select2.getOptions();
				for(WebElement we:options2)
				{
					System.out.println("verified pets dropdown");
					System.out.println(we.getText());
				}

				//verify degree dropdown
				WebElement degree= driver.findElement(By.id("graduation_degree"));
				Select select3 = new Select(degree);
				List<WebElement> options3 = select3.getOptions();
				for(WebElement we:options3)
				{
					System.out.println("verified degree dropdown");
					System.out.println(we.getText());
				} 
		
	}

	
	
}
